﻿using System;
using System.Collections.Generic;

#nullable disable

namespace WebAPI.Models
{
    public partial class Platform
    {
        public int PlatformId { get; set; }
        public string PlatformName { get; set; }
    }
}
